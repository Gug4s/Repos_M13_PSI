import sqlite3

conexao = sqlite3.connect('epbjc.db')
cursor = conexao.cursor()

# Query SELECT, com o SELECT ele extrai os dados pedidos
# Neste caso usa o operador * que seleciona tudo da tabela
# Pode ser usado a WHERE e o AND para filtrar a pesquisa, juntando com as condições ( > , < , = )

cursor.execute('SELECT * FROM professores')
 
resultados = cursor.fetchall()
 
for professor in resultados:
    print(professor)

print("O Programa correu com sucesso!")

conexao.commit()

conexao.close()
