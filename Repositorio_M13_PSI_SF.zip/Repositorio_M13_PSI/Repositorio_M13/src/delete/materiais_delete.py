import sqlite3
import random

conexao = sqlite3.connect('epbjc.db')
cursor = conexao.cursor()

# Query DELETE, que apaga os dados pedidos da tabela
# neste caso usa a cláusula WHERE, que ajuda a filtrar e o AND para filtrar ainda mais
# Para apagar a tabela é usado o DROP TABLE

cursor.execute("DELETE FROM materiais WHERE id = 1") 

conexao.commit()

conexao.close()