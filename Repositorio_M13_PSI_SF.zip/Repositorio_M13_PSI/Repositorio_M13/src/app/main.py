import sqlite3

# Criação da ligação do ficheiro, neste caso é "conexao"

conexao = sqlite3.connect('epbjc.db')
cursor = conexao.cursor()


# Criação das tabelas atraves do CREATE TABLE, com os seguintes atributos 
# INTEGER : Define que os dados inseridos sejam numeros, como por exemplo: 1, 2, 3
# AUTOINCREMENT: Define que a cada dado inserido, o valor vai aumentando, neste caso é o ID
# NOT NULL: Define que os dados inseridos não possam ser inseridos em vazio
# TEXT: Define que os dados inseridos sejam em string, como por ex: "João"

cursor.execute('''
CREATE TABLE IF NOT EXISTS Escola (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nome TEXT NOT NULL
)
''')


cursor.execute('''
CREATE TABLE IF NOT EXISTS alunos (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nome TEXT NOT NULL,
    idade TEXT NOT NULL,
    escola_id INTEGER,
    FOREIGN KEY (escola_id) REFERENCES Escola(id)
)
''')


cursor.execute('''
CREATE TABLE IF NOT EXISTS materiais (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    objeto TEXT NOT NULL,
    cor TEXT NOT NULL,
    escola_id INTEGER,
    FOREIGN KEY (escola_id) REFERENCES Escola(id)
)
''')


cursor.execute('''
CREATE TABLE IF NOT EXISTS professores (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nomeprof TEXT NOT NULL,
    disciplina TEXT NOT NULL,
    escola_id INTEGER,
    FOREIGN KEY (escola_id) REFERENCES Escola(id)
)
''')

conexao.commit()

conexao.close()
