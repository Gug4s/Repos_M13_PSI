import sqlite3
import random

conexao = sqlite3.connect('epbjc.db')
cursor = conexao.cursor()

primeiros_nomes = ["Diogo","Vera","Sandra","Carla","Inês","André","Marcelo","Helena","Ana"]
disciplina = ["PSI","MAT","PORT","ING","EF","RC","AI","SO"]


for _ in range(1, 21):

    nome_gerado = f"{random.choice(primeiros_nomes)}"
    disciplina_gerada = f"{random.choice(disciplina)}"
    
    # Query INSERT, que insere na tabela referida os dados inseridos nos campos mencionados através do VALUES
    cursor.execute('INSERT INTO professores (nomeprof,disciplina) VALUES (?, ?)', (nome_gerado,disciplina_gerada))

conexao.commit()

conexao.close()