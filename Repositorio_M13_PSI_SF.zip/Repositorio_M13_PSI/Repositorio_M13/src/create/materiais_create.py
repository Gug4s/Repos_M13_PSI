import sqlite3
import random

conexao = sqlite3.connect('epbjc.db')
cursor = conexao.cursor()

objeto = ["Caneta","Lápis","Marcador","Borracha","Caderno","Computador","Lápis de Cor","Corretor"]
cor = ["Vermelho","Azul","Rosa","Amarelo","Verde","Preto","Branco","Cinzento"]



for _ in range(1, 21):

    nome_gerado = f"{random.choice(objeto)}"
    cor_gerada = f"{random.choice(cor)}"

    # Query INSERT, que insere na tabela referida os dados inseridos nos campos mencionados através do VALUES
    cursor.execute('INSERT INTO materiais (objeto,cor) VALUES (?, ?)', (nome_gerado,cor_gerada))

conexao.commit()

conexao.close()