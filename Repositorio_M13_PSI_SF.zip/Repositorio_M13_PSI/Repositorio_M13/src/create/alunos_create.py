import sqlite3
import random

conexao = sqlite3.connect('epbjc.db')
cursor = conexao.cursor()

primeiros_nomes = ["Simão","Miguel","Francisco","Aléxis","David","Afonso","Iuri","Joel","Beatriz","Tiago","Pedro"]
ultimos_nomes = ["Ferreira","Eusébio","Santos","Roque","Gomes","Guerreiro","Gonçalves","Matoso","Novas","Moretti","Palma"]



for _ in range(1, 21):

    nome_gerado = f"{random.choice(primeiros_nomes)} {random.choice(ultimos_nomes)}"
    idade_aleatoria = random.randint(15, 21)

    # Query INSERT, que insere na tabela referida os dados inseridos nos campos mencionados através do VALUES
    cursor.execute('INSERT INTO alunos (nome,idade) VALUES (?, ?)', (nome_gerado,idade_aleatoria))

conexao.commit()

conexao.close()